import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class Server extends UnicastRemoteObject implements Interface{
    public Server() throws RemoteException{
        super();
    }
    public int fact(int a){
        int ans=1;
        for(int i=1;i<=a;i++){
            ans=ans*i;
            System.out.println(ans+" "+i);
        }

        return ans;
    }

    public static void main(String[] args) {
        try{
            Server s=new Server();
            Naming.rebind("facto",s);
            System.out.println("Server is running finely");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}