import java.rmi.Naming;

public class Client{
    public static void main(String[] args) {
        try {
            Interface f = (Interface) Naming.lookup("rmi://localhost/facto");
            int ans = f.fact(7);
            System.out.println("Answer is "+ ans);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}