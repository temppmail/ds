import java.rmi.Remote;
import java.rmi.RemoteException;
public interface Interface extends Remote
{
    int fact(int a) throws RemoteException;
}