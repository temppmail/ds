import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class Server {
    public static void main(String[] args) throws Exception {
        int serverPort = 12345;  // Server port
        DatagramSocket serverSocket = new DatagramSocket(serverPort);
        System.out.println("Server started... Waiting for clients.");

        List<InetAddress> clientAddresses = new ArrayList<>();
        List<Long> clientTimes = new ArrayList<>();

        while (true) {
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(receivePacket);

            InetAddress clientAddress = receivePacket.getAddress();
            long clientTime = Long.parseLong(new String(receivePacket.getData(), 0, receivePacket.getLength()));
            System.out.println("Received time from client at " + clientAddress + ": " + clientTime);

            // Store client info
            clientAddresses.add(clientAddress);
            clientTimes.add(clientTime);

            // If two clients have sent their time, process and send the average time
            if (clientAddresses.size() == 2) {
                long sum = 0;
                for (long time : clientTimes) {
                    sum += time;
                }
                long avgTime = sum / clientTimes.size();
                System.out.println("Calculated average time: " + avgTime);

                // Send the average time to all clients
                for (int i = 0; i < clientAddresses.size(); i++) {
                    String avgTimeMessage = String.valueOf(avgTime);
                    DatagramPacket sendPacket = new DatagramPacket(avgTimeMessage.getBytes(), avgTimeMessage.length(),
                            clientAddresses.get(i), receivePacket.getPort());
                    serverSocket.send(sendPacket);
                    System.out.println("Sent average time to client at " + clientAddresses.get(i));
                }

                // Clear the lists for the next round of clock synchronization
                clientAddresses.clear();
                clientTimes.clear();
            }
        }
    }
}
