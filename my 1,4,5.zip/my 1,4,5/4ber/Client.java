import java.net.*;

public class Client {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Usage: java TimeDaemonClient <client_id>");
            return;
        }

        int clientId = Integer.parseInt(args[0]);
        DatagramSocket clientSocket = new DatagramSocket();
        InetAddress serverAddress = InetAddress.getByName("192.168.1.9"); // Change to the server's IP address
        int serverPort = 12345;

        // Send the current time to the server
        long currentTime = System.currentTimeMillis();
        String timeMessage = String.valueOf(currentTime);
        DatagramPacket sendPacket = new DatagramPacket(timeMessage.getBytes(), timeMessage.length(), serverAddress, serverPort);
        clientSocket.send(sendPacket);
        System.out.println("Client " + clientId + " sent local time to server: " + currentTime);

        // Receive the average time from the server
        byte[] receiveData = new byte[1024];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
        clientSocket.receive(receivePacket);
        String avgTimeMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
        long avgTime = Long.parseLong(avgTimeMessage);
        System.out.println("Client " + clientId + " received average time from server: " + avgTime);

        // Calculate the adjustment needed
        long adjustment = avgTime - currentTime;
        System.out.println("Client " + clientId + " adjustment needed: " + adjustment + "ms");

        clientSocket.close();
    }
}
