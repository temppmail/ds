import java.net.*;
import java.io.*;

public class Node {
    public static void main(String[] args) throws Exception {
        if (args.length != 4) {
            System.out.println("Usage: java Node <my_port> <next_ip> <next_port> <has_token>");
            return;
        }

        int myPort = Integer.parseInt(args[0]);
        String nextIP = args[1];
        int nextPort = Integer.parseInt(args[2]);
        boolean hasToken = args[3].equals("true");

        DatagramSocket socket = new DatagramSocket(myPort);
        InetAddress nextAddress = InetAddress.getByName(nextIP);

        if (hasToken) {
            // If initially has token, immediately start critical section
            enterCriticalSection();
            sendToken(socket, nextAddress, nextPort);
        }

        byte[] buffer = new byte[1024];

        while (true) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);

            String message = new String(packet.getData(), 0, packet.getLength());
            if (message.equals("TOKEN")) {
//                System.out.println("My port "+myPort+" "+"Next IP is "+nextIP);
                System.out.println("Token received!");

                enterCriticalSection();
                sendToken(socket, nextAddress, nextPort);
            }
        }
    }

    private static void enterCriticalSection() throws InterruptedException {
        System.out.println("Entering Critical Section...");
        Thread.sleep(2000); // Simulate work in CS
        System.out.println("Exiting Critical Section...");
    }

    private static void sendToken(DatagramSocket socket, InetAddress nextAddress, int nextPort) throws IOException {
        String token = "TOKEN";
        byte[] data = token.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, nextAddress, nextPort);
        socket.send(packet);
        System.out.println("Token sent to next node.");
    }
}
